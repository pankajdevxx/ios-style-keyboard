# iOS Style Keyboard (Android / Kotlin)

A starter Android Input Method Editor (IME) with a custom QWERTY keyboard and an iOS-inspired emoji picker.

## Features
- System-wide custom keyboard through Android `InputMethodService`.
- QWERTY, shift, number/symbol toggle, delete, space and editor action/enter.
- Emoji picker with category sections and a search field.
- Demo activity with setup shortcuts.

## Emoji appearance and licensing
Emoji are inserted as standard Unicode sequences. Their final appearance is controlled by the receiving app/device's emoji font. This project does **not** bundle Apple's proprietary San Francisco/Apple Color Emoji font or artwork. Therefore it offers an iOS-inspired picker layout, not guaranteed pixel-identical Apple emoji on every Android device. To provide consistent artwork in your own app's views, use a properly licensed emoji image set and render those assets in app-owned UI. A third-party IME cannot force WhatsApp, Instagram, or another app to replace its own emoji renderer.

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Gradle 8.9-compatible Android Gradle Plugin (the project plugin is 8.7.3)

## Open and build
1. Extract this ZIP.
2. In Android Studio choose **Open** and select the `ios_style_keyboard` project folder.
3. Allow Gradle sync and install missing SDK components if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, from the project root with Gradle installed:
```bash
gradle assembleDebug
```

## Enable on a device
1. Install the debug APK.
2. Open **iOS Style Keyboard**.
3. Tap **Enable keyboard** and enable this keyboard in Android settings.
4. Tap **Choose keyboard** and select **iOS Style Keyboard**.
5. Tap the demo input or any text field to use it. Use the 🙂 key to open emoji mode.

Android displays a security warning when enabling a third-party keyboard. Review the app before enabling it. This sample does not request Internet access and does not transmit typed text.

## Project structure
```text
ios_style_keyboard/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/iosstylekeyboard/
│       │   ├── MainActivity.kt
│       │   └── KeyboardService.kt
│       └── res/
│           ├── values/styles.xml
│           └── xml/method.xml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Notes / next steps
- This is a functional starter IME, not a production replacement for Gboard. Add accessibility testing, multilingual layouts, long-press alternates, autocorrect, glide typing, privacy review, and device-specific testing before release.
- The category chips are visual navigation affordances in this starter; sections are vertically grouped and searchable. Implement section scrolling for a polished production picker.
- The keyboard intentionally does not request network or broad storage permissions.


## Build using only an Android phone (GitHub Actions)

This project includes `.github/workflows/build-apk.yml`. You can use GitHub's cloud runner from Chrome on your phone, so you do not need Android Studio or a local Gradle installation.

1. Extract the project ZIP using your phone's Files app.
2. In Chrome, sign in at https://github.com and create a **private** repository, for example `ios-style-keyboard`.
3. Open the empty repository and use **Add file → Upload files**. Upload the *contents* of the extracted project folder (including the hidden `.github` folder and its `workflows/build-apk.yml` file). Do not upload only the ZIP file.
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build Android Debug APK** in the workflow list.
6. Tap **Run workflow**, keep branch `main`, and tap the green **Run workflow** button.
7. Open the new workflow run. Wait for the job to show a green check mark.
8. Open the run's **Artifacts** section and download `ios-style-keyboard-debug-apk`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
10. Open `app-debug.apk` on your phone and install it. If Android asks, allow Chrome or Files to install unknown apps for this installation.

The workflow builds with JDK 17, Gradle 8.9, Android SDK 35 and uploads the debug APK as a downloadable Actions artifact. GitHub's current Actions interface may look slightly different on mobile.

If the workflow fails, open the failed run, expand the red failed step, and copy the first meaningful error (not just the final `BUILD FAILED` line).

