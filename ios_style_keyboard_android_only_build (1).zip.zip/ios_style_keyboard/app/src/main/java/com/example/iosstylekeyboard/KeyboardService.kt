package com.example.iosstylekeyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class KeyboardService : InputMethodService() {
    private val bg = Color.rgb(218, 220, 228)
    private val key = Color.rgb(250, 250, 253)
    private val accent = Color.rgb(105, 91, 214)
    private var root: LinearLayout? = null
    private var emojiMode = false
    private var caps = true
    private var symbols = false
    private var searchText = ""

    private val emojiGroups = linkedMapOf(
        "Recently used" to listOf("😀","😂","🥹","😍","🥰","😘","😊","😭","😎","🤔","🙌","❤️"),
        "Smileys" to listOf("😀","😃","😄","😁","😆","😅","😂","🤣","🥲","🥹","☺️","😊","😇","🙂","🙃","😉","😍","🥰","😘","😗","😙","😚","😋","😛","😜","🤪","🤨","🧐","🤓","😎","🥸","🤩","🥳","😏","😒","😞","😔","😟","😕","🙁","☹️","😣","😖","😫","😩","🥺","😭","😤","😠","😡","🤯","😳","🥵","🥶","😱","😨","😰","😥","😓","🤗","🤔","🫣","🤭","🫢","🫡","🤫","🫠"),
        "People" to listOf("👋","🤚","🖐️","✋","🖖","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","👇","☝️","👍","👎","✊","👊","🤛","🤜","👏","🙌","🫶","👐","🤲","🙏","💪","🦾","🧠","👀","👁️","👶","🧒","👦","👧","🧑","👨","👩"),
        "Animals" to listOf("🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐻‍❄️","🐨","🐯","🦁","🐮","🐷","🐸","🐵","🙈","🙉","🙊","🐔","🐧","🐦","🦆","🦅","🦉","🦇","🐺","🐗","🐴","🦄","🐝","🦋","🐌","🐞","🐢","🐍","🦖","🐙","🦀","🐬","🐳"),
        "Food" to listOf("🍏","🍎","🍐","🍊","🍋","🍌","🍉","🍇","🍓","🫐","🍈","🍒","🍑","🥭","🍍","🥥","🥝","🍅","🥑","🍆","🥔","🥕","🌽","🌶️","🥒","🥬","🥦","🧄","🧅","🍞","🥐","🧀","🍕","🍔","🍟","🌭","🍿","🍩","🍪","🎂","🍰","☕","🧋"),
        "Activities" to listOf("⚽","🏀","🏈","⚾","🎾","🏐","🎱","🏓","🏸","🥇","🏆","🎮","🕹️","🎯","🎲","🎨","🎤","🎧","🎸","🎹","🎬","🎭"),
        "Travel" to listOf("🚗","🚕","🚌","🚎","🏎️","🚓","🚑","🚒","🚲","🛵","✈️","🚀","🚁","🚂","🚢","⛵","🏝️","🏖️","🏕️","🏠","🏙️","🌋","🌈","☀️","🌙","⭐","🌍"),
        "Symbols" to listOf("❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💯","💢","💥","💫","💦","💨","💬","💭","✅","❌","⚠️","✨","🔥","🎉","🎊")
    )

    override fun onCreateInputView(): View {
        emojiMode = false
        return buildKeyboard()
    }

    private fun rounded(color: Int, radius: Float = 12f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(4, 7, 4, 7)
        setBackgroundColor(bg)
    }

    private fun makeButton(label: String, color: Int = key, textColor: Int = Color.rgb(35,35,45),
                           weight: Float = 1f, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = if (label.length > 2) 16f else 19f
            setTextColor(textColor)
            isAllCaps = false
            background = rounded(color, 10f)
            stateListAnimator = null
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, 48, weight).apply {
                setMargins(3, 3, 3, 3)
            }
            setOnClickListener { action() }
        }
    }

    private fun row(parent: LinearLayout, labels: List<String>, special: Map<Int, Pair<String, () -> Unit>> = emptyMap()) {
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        labels.forEachIndexed { index, label ->
            val spec = special[index]
            val button = if (spec != null) makeButton(spec.first, if (index == 0) accent else Color.rgb(190,194,207),
                if (index == 0) Color.WHITE else Color.DKGRAY, if (label == "SPACE") 4f else 1.5f, spec.second)
            else makeButton(if (caps) label.uppercase() else label, action = { type(label) })
            if (label == "SPACE") button.text = " "
            line.addView(button)
        }
        parent.addView(line)
    }

    private fun buildKeyboard(): View {
        val panel = base()
        root = panel
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(makeButton("🙂", Color.rgb(235,235,244), accent, 1f) { showEmojiPicker() })
        top.addView(makeButton("GIF", Color.rgb(235,235,244), accent, 1f) {
            Toast.makeText(this@KeyboardService, "GIF support can be added in a future version", Toast.LENGTH_SHORT).show()
        })
        top.addView(makeButton("⚙", Color.rgb(235,235,244), accent, 1f) {
            Toast.makeText(this@KeyboardService, "Keyboard settings", Toast.LENGTH_SHORT).show()
        })
        panel.addView(top)
        val a = if (symbols) listOf("1","2","3","4","5","6","7","8","9","0") else listOf("q","w","e","r","t","y","u","i","o","p")
        val b = if (symbols) listOf("@","#","$","%","&","-","+","(",")","/") else listOf("a","s","d","f","g","h","j","k","l")
        val c = if (symbols) listOf("*", "\"", "'", ":", ";", "!", "?") else listOf("z","x","c","v","b","n","m")
        row(panel, a)
        row(panel, b)
        val third = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        third.addView(makeButton("⇧", Color.rgb(190,194,207), Color.DKGRAY, 1.5f) { caps = !caps; refresh() })
        c.forEach { ch -> third.addView(makeButton(ch, action = { type(ch.trim()) })) }
        third.addView(makeButton("⌫", Color.rgb(190,194,207), Color.DKGRAY, 1.5f) { deleteOne() })
        panel.addView(third)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(makeButton("?123", Color.rgb(190,194,207), Color.DKGRAY, 1.4f) { symbols = !symbols; refresh() })
        bottom.addView(makeButton(",", action = { type(",") }))
        bottom.addView(makeButton("SPACE", weight = 4f) { type(" ") })
        bottom.addView(makeButton(".", action = { type(".") }))
        bottom.addView(makeButton("↵", accent, Color.WHITE, 1.4f) { enter() })
        panel.addView(bottom)
        return panel
    }

    private fun refresh() {
        setInputView(buildKeyboard())
    }

    private fun type(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    private fun deleteOne() {
        val connection = currentInputConnection ?: return
        val selected = connection.getSelectedText(0)
        if (!selected.isNullOrEmpty()) connection.commitText("", 1)
        else connection.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val info = currentInputEditorInfo
        val action = info?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val connection = currentInputConnection ?: return
        if (action == EditorInfo.IME_ACTION_DONE || action == EditorInfo.IME_ACTION_GO ||
            action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_SEND) {
            connection.performEditorAction(action)
        } else connection.commitText("\n", 1)
    }

    private fun showEmojiPicker() {
        emojiMode = true
        val panel = base()
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(makeButton("⌨", Color.rgb(235,235,244), accent, 0.8f) {
            emojiMode = false; setInputView(buildKeyboard())
        })
        val search = EditText(this).apply {
            hint = "Search emoji"
            textSize = 15f
            singleLine = true
            setPadding(14, 0, 14, 0)
            background = rounded(Color.WHITE, 18f)
        }
        header.addView(search, LinearLayout.LayoutParams(0, 44, 4f).apply { setMargins(4,0,4,0) })
        panel.addView(header)

        val categories = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        emojiGroups.keys.forEach { name ->
            categoryRow.addView(makeButton(categoryIcon(name), Color.rgb(235,235,244), accent, 1f) {
                scrollToCategory(name)
            }.apply { tag = name })
        }
        categories.addView(categoryRow)
        panel.addView(categories)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun populate(filter: String = "") {
            content.removeAllViews()
            emojiGroups.forEach { (name, emojis) ->
                val filtered = emojis.filter { filter.isBlank() || it.contains(filter) }
                if (filtered.isNotEmpty()) {
                    content.addView(TextView(this).apply {
                        text = name; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.DKGRAY); setPadding(8, 10, 4, 4)
                    })
                    val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    filtered.chunked(8).forEach { chunk ->
                        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                        chunk.forEach { emoji ->
                            line.addView(TextView(this).apply {
                                text = emoji; textSize = 27f; gravity = Gravity.CENTER
                                setPadding(0, 7, 0, 7)
                                setOnClickListener { type(emoji) }
                            }, LinearLayout.LayoutParams(0, 44, 1f))
                        }
                        repeat(8 - chunk.size) { line.addView(View(this), LinearLayout.LayoutParams(0, 44, 1f)) }
                        grid.addView(line)
                    }
                    content.addView(grid)
                }
            }
        }
        populate()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = populate(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) {}
        })
        setInputView(panel)
    }

    private fun categoryIcon(name: String) = when (name) {
        "Recently used" -> "◷"
        "Smileys" -> "😀"
        "People" -> "👋"
        "Animals" -> "🐻"
        "Food" -> "🍔"
        "Activities" -> "⚽"
        "Travel" -> "🚗"
        else -> "❤️"
    }

    private fun scrollToCategory(name: String) {
        // Category buttons remain usable; search and grouped sections are available in the picker.
        Toast.makeText(this, name, Toast.LENGTH_SHORT).show()
    }
}
