package com.example.iosstylekeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(Color.rgb(246, 246, 250))
        }
        val title = TextView(this).apply {
            text = "iOS Style Keyboard"
            textSize = 27f
            setTextColor(Color.rgb(30, 30, 40))
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Enable the keyboard, then select it from the input method switcher."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 10, 0, 20)
        }
        val enable = Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Choose keyboard"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        }
        val demoLabel = TextView(this).apply {
            text = "Try it here"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.DKGRAY)
            setPadding(0, 24, 0, 8)
        }
        val input = EditText(this).apply {
            hint = "Tap here and open the emoji button 🙂"
            textSize = 18f
            minLines = 3
            gravity = Gravity.TOP
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.WHITE)
        }
        page.addView(title)
        page.addView(subtitle)
        page.addView(enable)
        page.addView(choose)
        page.addView(demoLabel)
        page.addView(input, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }
}
